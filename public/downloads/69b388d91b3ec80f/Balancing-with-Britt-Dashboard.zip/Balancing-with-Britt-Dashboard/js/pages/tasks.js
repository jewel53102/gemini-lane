let _taskStatusFilter = "open";
let _taskClientFilter = "";

document.addEventListener("DOMContentLoaded", function () {
  initChrome("tasks", "To-Do List");
  window.__rerenderPage = renderAll;

  const clientSel = document.getElementById("client-filter");
  const clients = DB.clients.all().sort(function (a, b) { return (a.business || "").localeCompare(b.business || ""); });
  clientSel.innerHTML = '<option value="">All Clients</option><option value="__internal">Internal (no client)</option>' +
    clients.map(function (c) { return '<option value="' + c.id + '">' + escapeHTML(c.business) + '</option>'; }).join("");
  clientSel.addEventListener("change", function () { _taskClientFilter = clientSel.value; renderAll(); });

  document.querySelectorAll("#status-tabs .tab").forEach(function (tab) {
    tab.addEventListener("click", function () {
      document.querySelectorAll("#status-tabs .tab").forEach(function (t) { t.classList.remove("active"); });
      tab.classList.add("active");
      _taskStatusFilter = tab.dataset.status;
      renderAll();
    });
  });

  renderAll();
});

function renderAll() {
  renderTaskList();
  renderTemplateList();
}

function renderTaskList() {
  const list = document.getElementById("task-list");
  let tasks = DB.tasks.all();
  if (_taskStatusFilter !== "all") tasks = tasks.filter(function (t) { return (t.status === "done") === (_taskStatusFilter === "done"); });
  if (_taskClientFilter === "__internal") tasks = tasks.filter(function (t) { return !t.clientId; });
  else if (_taskClientFilter) tasks = tasks.filter(function (t) { return t.clientId === _taskClientFilter; });

  tasks.sort(function (a, b) {
    if (!a.dueDate) return 1;
    if (!b.dueDate) return -1;
    return a.dueDate.localeCompare(b.dueDate);
  });

  if (tasks.length === 0) {
    list.innerHTML = '<div class="empty"><div class="empty-ico">✅</div><div class="empty-txt">No tasks here.</div></div>';
    return;
  }
  list.innerHTML = tasks.map(function (t) { return renderTaskRow(t); }).join("");
}

function renderTemplateList() {
  const list = document.getElementById("template-list");
  const templates = DB.templates.all();
  if (templates.length === 0) {
    list.innerHTML = '<div class="empty"><div class="empty-ico">🔁</div><div class="empty-txt">No recurring task series yet — set one up for work like monthly reconciliations or quarterly filings.</div></div>';
    return;
  }
  list.innerHTML = templates.map(function (tpl) {
    const cn = tpl.clientId ? clientName(tpl.clientId) : "Internal";
    return '' +
      '<div class="task-row">' +
      '  <div class="task-body">' +
      '    <div class="task-title">' + escapeHTML(tpl.title) + '</div>' +
      '    <div class="task-meta-row">' +
      '      <span class="badge b-teal">' + (tpl.freq === "biweekly" ? "Bi-Weekly" : tpl.freq.charAt(0).toUpperCase() + tpl.freq.slice(1)) + '</span>' +
      '      <span class="muted">first due ' + fmtDate(tpl.anchorDate) + '</span>' +
      '      <span class="task-client-tag">' + escapeHTML(cn) + '</span>' +
      '    </div>' +
      '  </div>' +
      '  <div class="task-actions" style="opacity:1">' +
      '    <button class="btn btn-ghost btn-icon btn-sm" onclick="openTemplateForm(\'' + tpl.id + '\')" title="Edit">✎</button>' +
      '    <button class="btn btn-ghost btn-icon btn-sm" onclick="deleteTemplate(\'' + tpl.id + '\')" title="Delete">🗑</button>' +
      '  </div>' +
      '</div>';
  }).join("");
}
