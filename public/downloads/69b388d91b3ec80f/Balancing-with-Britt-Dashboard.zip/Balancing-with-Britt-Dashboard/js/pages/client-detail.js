let _clientId = null;
let _activeTab = "overview";

document.addEventListener("DOMContentLoaded", function () {
  _clientId = new URLSearchParams(location.search).get("id");
  window.__rerenderPage = renderClientDetail;
  renderClientDetail();
});

function renderClientDetail() {
  const c = _clientId ? DB.clients.get(_clientId) : null;
  initChrome("clients", c ? c.business : "Client Not Found");

  const content = document.getElementById("client-content");
  if (!c) {
    content.innerHTML = '<div class="empty"><div class="empty-ico">🚫</div><div class="empty-txt">Client not found.</div><button class="btn btn-primary btn-sm" onclick="location.href=\'clients.html\'">Back to Clients</button></div>';
    return;
  }

  const tasks = DB.tasks.all().filter(function (t) { return t.clientId === c.id; });
  const openTasks = tasks.filter(function (t) { return t.status !== "done"; });
  const invoices = DB.invoices.all().filter(function (i) { return i.clientId === c.id; });
  const unpaidInvoices = invoices.filter(function (i) { return i.status !== "paid"; });
  const docs = Docs.all().filter(function (d) { return d.clientId === c.id; });
  const statusBadge = c.status === "active" ? "b-green" : c.status === "prospect" ? "b-blue" : "b-gray";

  content.innerHTML = '' +
    '<div class="ph">' +
    '  <div class="flex gap-8 items-c">' +
    '    <div class="client-avatar" style="width:52px;height:52px;font-size:18px">' + initials(c.business) + '</div>' +
    '    <div>' +
    '      <div class="ph-title">' + escapeHTML(c.business) + '</div>' +
    '      <div class="ph-sub">' + escapeHTML(c.contactName || "") + (c.email ? " · " + escapeHTML(c.email) : "") + (c.phone ? " · " + escapeHTML(c.phone) : "") + '</div>' +
    '    </div>' +
    '  </div>' +
    '  <div class="flex gap-8">' +
    '    <button class="btn btn-ghost" onclick="location.href=\'clients.html\'">← All Clients</button>' +
    '    <button class="btn btn-primary" onclick="openClientForm(\'' + c.id + '\')">Edit Client</button>' +
    '  </div>' +
    '</div>' +

    '<div class="client-meta-row mb-20">' +
    '  <span class="badge ' + statusBadge + '">' + escapeHTML(c.status || "active") + '</span>' +
    (c.entityType ? '<span class="badge b-gray">' + escapeHTML(c.entityType) + '</span>' : '') +
    (c.billingFrequency ? '<span class="badge b-teal">' + escapeHTML(c.billingFrequency) + (c.rate ? " · " + fmtMoney(c.rate) : "") + '</span>' : '') +
    (c.softwareUsed ? '<span class="badge b-purple">' + escapeHTML(c.softwareUsed) + '</span>' : '') +
    '</div>' +

    '<div class="tabs" id="detail-tabs">' +
    '  <button class="tab' + (_activeTab === "overview" ? " active" : "") + '" data-tab="overview">Overview</button>' +
    '  <button class="tab' + (_activeTab === "tasks" ? " active" : "") + '" data-tab="tasks">Tasks (' + openTasks.length + ')</button>' +
    '  <button class="tab' + (_activeTab === "invoices" ? " active" : "") + '" data-tab="invoices">Invoices (' + unpaidInvoices.length + ')</button>' +
    '</div>' +

    '<div class="tp' + (_activeTab === "overview" ? " active" : "") + '" id="tp-overview">' +
    '  <div class="g2">' +
    '    <div class="card">' +
    '      <div class="card-hd"><span class="card-title">Services Provided</span></div>' +
    '      <div class="card-body">' +
    (c.services && c.services.length ? '<div class="client-meta-row">' + c.services.map(function (s) { return '<span class="badge b-gray">' + escapeHTML(s) + '</span>'; }).join("") + '</div>' : '<div class="muted">No services listed yet.</div>') +
    '      </div>' +
    '    </div>' +
    '    <div class="card">' +
    '      <div class="card-hd"><span class="card-title">Details</span></div>' +
    '      <div class="card-body">' +
    '        <div class="muted mb-8">Start Date: ' + (c.startDate ? fmtDate(c.startDate) : "—") + '</div>' +
    '        <div class="muted">Rate: ' + (c.rate ? fmtMoney(c.rate) + " / " + (c.billingFrequency || "period") : "—") + '</div>' +
    '      </div>' +
    '    </div>' +
    '  </div>' +
    '  <div class="card mt-8">' +
    '    <div class="card-hd"><span class="card-title">Logins &amp; Passwords</span><button class="btn btn-ghost btn-sm" onclick="openClientForm(\'' + c.id + '\')">Edit</button></div>' +
    '    <div class="card-body">' +
    '      <div class="notice mb-8"><span class="notice-ico">⚠️</span><span>Plain text, not encrypted — fine for local use on your own machine only.</span></div>' +
    (c.loginInfo ? '<div style="white-space:pre-wrap;font-size:13px;line-height:1.6;font-family:\'SF Mono\',Menlo,monospace">' + escapeHTML(c.loginInfo) + '</div>' : '<div class="muted">No logins saved yet. Click Edit to add them.</div>') +
    '    </div>' +
    '  </div>' +
    '  <div class="card mt-8">' +
    '    <div class="card-hd"><span class="card-title">Documents</span>' +
    (docs.length > 0 ? '<button class="btn btn-ghost btn-sm" onclick="downloadAllFiles(\'' + c.id + '\')">⬇ Download All</button>' : '') +
    '    </div>' +
    '    <div class="card-body">' +
    '      <div class="dropzone mb-16" id="client-dropzone">' +
    '        <div class="dropzone-ico">📁</div>' +
    '        <div class="dropzone-txt">Drag files here, or click to upload</div>' +
    '        <div class="dropzone-sub">Stored locally in this browser, filed under this client</div>' +
    '        <input type="file" id="client-file-input" style="display:none" multiple>' +
    '      </div>' +
    (docs.length === 0 ? '<div class="empty"><div class="empty-ico">📁</div><div class="empty-txt">No documents for this client yet.</div></div>' :
      '<div class="doc-grid">' + docs.map(function (d) { return renderDocCard(d, { hideClient: true }); }).join("") + '</div>') +
    '    </div>' +
    '  </div>' +
    '  <div class="card mt-8">' +
    '    <div class="card-hd"><span class="card-title">Notes</span></div>' +
    '    <div class="card-body">' + (c.notes ? '<div style="white-space:pre-wrap;font-size:13px;line-height:1.6">' + escapeHTML(c.notes) + '</div>' : '<div class="muted">No notes yet.</div>') + '</div>' +
    '  </div>' +
    '</div>' +

    '<div class="tp' + (_activeTab === "tasks" ? " active" : "") + '" id="tp-tasks">' +
    '  <div class="card">' +
    '    <div class="card-hd"><span class="card-title">Tasks for ' + escapeHTML(c.business) + '</span>' +
    '      <div class="flex gap-8">' +
    '        <button class="btn btn-ghost btn-sm" onclick="openTemplateForm(null, \'' + c.id + '\')">+ Recurring</button>' +
    '        <button class="btn btn-primary btn-sm" onclick="openTaskForm(null, \'' + c.id + '\')">+ New Task</button>' +
    '      </div>' +
    '    </div>' +
    '    <div class="card-body">' +
    (tasks.length === 0 ? '<div class="empty"><div class="empty-ico">✅</div><div class="empty-txt">No tasks for this client yet.</div></div>' :
      tasks.sort(function (a, b) { return (a.dueDate || "").localeCompare(b.dueDate || ""); }).map(function (t) { return renderTaskRow(t, { hideClient: true }); }).join("")) +
    '    </div>' +
    '  </div>' +
    '</div>' +

    '<div class="tp' + (_activeTab === "invoices" ? " active" : "") + '" id="tp-invoices">' +
    '  <div class="card">' +
    '    <div class="card-hd"><span class="card-title">Invoices for ' + escapeHTML(c.business) + '</span>' +
    '      <button class="btn btn-primary btn-sm" onclick="openInvoiceForm(null, \'' + c.id + '\')">+ New Invoice</button>' +
    '    </div>' +
    '    <div class="card-body">' +
    (invoices.length === 0 ? '<div class="empty"><div class="empty-ico">🧾</div><div class="empty-txt">No invoices for this client yet.</div></div>' :
      '<div class="invoice-row hd"><span>Invoice #</span><span>Notes</span><span>Amount</span><span>Due</span><span>Status</span><span></span></div>' +
      invoices.sort(function (a, b) { return (a.dueDate || "").localeCompare(b.dueDate || ""); }).map(function (i) { return renderInvoiceRow(i, { hideClient: true }); }).join("")) +
    '    </div>' +
    '  </div>' +
    '</div>';

  document.querySelectorAll("#detail-tabs .tab").forEach(function (tab) {
    tab.addEventListener("click", function () {
      _activeTab = tab.dataset.tab;
      renderClientDetail();
    });
  });

  wireClientDropzone(c.id);
}

function wireClientDropzone(clientId) {
  const dz = document.getElementById("client-dropzone");
  const fileInput = document.getElementById("client-file-input");
  if (!dz || !fileInput) return;
  dz.addEventListener("click", function () { fileInput.click(); });
  fileInput.addEventListener("change", function () { handleDroppedFiles(fileInput.files, clientId); fileInput.value = ""; });
  ["dragenter", "dragover"].forEach(function (ev) { dz.addEventListener(ev, function (e) { e.preventDefault(); dz.classList.add("drag"); }); });
  ["dragleave", "drop"].forEach(function (ev) { dz.addEventListener(ev, function (e) { e.preventDefault(); dz.classList.remove("drag"); }); });
  dz.addEventListener("drop", function (e) { handleDroppedFiles(e.dataTransfer.files, clientId); });
}
