let _docCategoryFilter = "";
let _docClientFilter = "";

document.addEventListener("DOMContentLoaded", function () {
  initChrome("documents", "Documents");
  window.__rerenderPage = renderAll;

  const catSel = document.getElementById("category-filter");
  catSel.innerHTML = '<option value="">All Categories</option>' + DOC_CATEGORIES.map(function (c) { return '<option>' + c + '</option>'; }).join("");
  catSel.addEventListener("change", function () { _docCategoryFilter = catSel.value; renderAll(); });

  const clientSel = document.getElementById("client-filter");
  const clients = DB.clients.all().sort(function (a, b) { return (a.business || "").localeCompare(b.business || ""); });
  clientSel.innerHTML = '<option value="">All Clients</option><option value="__internal">Internal (no client)</option>' +
    clients.map(function (c) { return '<option value="' + c.id + '">' + escapeHTML(c.business) + '</option>'; }).join("");
  clientSel.addEventListener("change", function () { _docClientFilter = clientSel.value; renderAll(); });

  const dz = document.getElementById("dropzone");
  const fileInput = document.getElementById("file-input");
  dz.addEventListener("click", function () { fileInput.click(); });
  fileInput.addEventListener("change", function () { handleDroppedFiles(fileInput.files); fileInput.value = ""; });
  ["dragenter", "dragover"].forEach(function (ev) { dz.addEventListener(ev, function (e) { e.preventDefault(); dz.classList.add("drag"); }); });
  ["dragleave", "drop"].forEach(function (ev) { dz.addEventListener(ev, function (e) { e.preventDefault(); dz.classList.remove("drag"); }); });
  dz.addEventListener("drop", function (e) { handleDroppedFiles(e.dataTransfer.files); });

  renderAll();
});

function renderAll() {
  let docs = Docs.all();
  if (_docCategoryFilter) docs = docs.filter(function (d) { return d.category === _docCategoryFilter; });
  if (_docClientFilter === "__internal") docs = docs.filter(function (d) { return !d.clientId; });
  else if (_docClientFilter) docs = docs.filter(function (d) { return d.clientId === _docClientFilter; });

  docs.sort(function (a, b) { return (b.uploadedAt || "").localeCompare(a.uploadedAt || ""); });

  const grid = document.getElementById("doc-grid");
  if (docs.length === 0) {
    grid.innerHTML = '<div class="empty" style="grid-column:1/-1"><div class="empty-ico">📁</div><div class="empty-txt">No documents match. Upload one above.</div></div>';
    return;
  }
  grid.innerHTML = docs.map(function (d) { return renderDocCard(d); }).join("");
}
