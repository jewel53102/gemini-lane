let _invStatusFilter = "unpaid";
let _invClientFilter = "";

document.addEventListener("DOMContentLoaded", function () {
  initChrome("invoices", "Invoices");
  window.__rerenderPage = renderAll;

  const clientSel = document.getElementById("client-filter");
  const clients = DB.clients.all().sort(function (a, b) { return (a.business || "").localeCompare(b.business || ""); });
  clientSel.innerHTML = '<option value="">All Clients</option>' + clients.map(function (c) { return '<option value="' + c.id + '">' + escapeHTML(c.business) + '</option>'; }).join("");
  clientSel.addEventListener("change", function () { _invClientFilter = clientSel.value; renderAll(); });

  document.querySelectorAll("#status-tabs .tab").forEach(function (tab) {
    tab.addEventListener("click", function () {
      document.querySelectorAll("#status-tabs .tab").forEach(function (t) { t.classList.remove("active"); });
      tab.classList.add("active");
      _invStatusFilter = tab.dataset.status;
      renderAll();
    });
  });

  renderAll();
});

function renderAll() {
  const all = DB.invoices.all();
  const today = todayStr();
  const monthPrefix = today.slice(0, 7);

  const unpaidTotal = all.filter(function (i) { return i.status !== "paid"; }).reduce(function (s, i) { return s + (Number(i.amount) || 0); }, 0);
  const overdueTotal = all.filter(function (i) { return i.status !== "paid" && i.dueDate && i.dueDate < today; }).reduce(function (s, i) { return s + (Number(i.amount) || 0); }, 0);
  const paidMtd = all.filter(function (i) { return i.status === "paid" && i.paidAt && i.paidAt.slice(0, 7) === monthPrefix; }).reduce(function (s, i) { return s + (Number(i.amount) || 0); }, 0);

  document.getElementById("s-unpaid").textContent = fmtMoney(unpaidTotal);
  document.getElementById("s-overdue").textContent = fmtMoney(overdueTotal);
  document.getElementById("s-paid-mtd").textContent = fmtMoney(paidMtd);
  document.getElementById("s-count").textContent = all.length;

  let invoices = all;
  if (_invStatusFilter === "unpaid") invoices = invoices.filter(function (i) { return i.status !== "paid"; });
  else if (_invStatusFilter === "paid") invoices = invoices.filter(function (i) { return i.status === "paid"; });
  if (_invClientFilter) invoices = invoices.filter(function (i) { return i.clientId === _invClientFilter; });

  invoices.sort(function (a, b) { return (a.dueDate || "").localeCompare(b.dueDate || ""); });

  const list = document.getElementById("invoice-list");
  if (invoices.length === 0) {
    list.innerHTML = '<div class="empty"><div class="empty-ico">🧾</div><div class="empty-txt">No invoices here.</div></div>';
    return;
  }
  list.innerHTML = invoices.map(function (i) { return renderInvoiceRow(i); }).join("");
}
