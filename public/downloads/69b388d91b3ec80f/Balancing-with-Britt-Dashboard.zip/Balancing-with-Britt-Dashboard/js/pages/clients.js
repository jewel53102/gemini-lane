let _statusFilter = "all";
let _searchTerm = "";

document.addEventListener("DOMContentLoaded", function () {
  initChrome("clients", "Clients");
  window.__rerenderPage = renderClients;
  renderClients();

  document.querySelectorAll("#status-tabs .tab").forEach(function (tab) {
    tab.addEventListener("click", function () {
      document.querySelectorAll("#status-tabs .tab").forEach(function (t) { t.classList.remove("active"); });
      tab.classList.add("active");
      _statusFilter = tab.dataset.status;
      renderClients();
    });
  });
  document.getElementById("search-input").addEventListener("input", function (e) {
    _searchTerm = e.target.value.toLowerCase();
    renderClients();
  });
});

function renderClients() {
  const grid = document.getElementById("client-grid");
  let clients = DB.clients.all();
  if (_statusFilter !== "all") clients = clients.filter(function (c) { return c.status === _statusFilter; });
  if (_searchTerm) {
    clients = clients.filter(function (c) {
      return (c.business || "").toLowerCase().indexOf(_searchTerm) > -1 ||
        (c.contactName || "").toLowerCase().indexOf(_searchTerm) > -1;
    });
  }
  clients.sort(function (a, b) { return (a.business || "").localeCompare(b.business || ""); });

  if (clients.length === 0) {
    grid.innerHTML = '<div class="empty" style="grid-column:1/-1"><div class="empty-ico">👥</div><div class="empty-txt">No clients match.</div><button class="btn btn-primary btn-sm" onclick="openClientForm()">+ New Client</button></div>';
    return;
  }

  const today = todayStr();
  grid.innerHTML = clients.map(function (c) {
    const openTasks = DB.tasks.all().filter(function (t) { return t.clientId === c.id && t.status !== "done"; }).length;
    const overdueTasks = DB.tasks.all().filter(function (t) { return t.clientId === c.id && t.status !== "done" && t.dueDate && t.dueDate < today; }).length;
    const unpaidTotal = DB.invoices.all().filter(function (i) { return i.clientId === c.id && i.status !== "paid"; })
      .reduce(function (s, i) { return s + (Number(i.amount) || 0); }, 0);
    const statusBadge = c.status === "active" ? "b-green" : c.status === "prospect" ? "b-blue" : "b-gray";
    return '' +
      '<div class="client-card" onclick="location.href=\'client-detail.html?id=' + c.id + '\'">' +
      '  <div class="client-card-top">' +
      '    <div class="flex gap-8 items-c">' +
      '      <div class="client-avatar">' + initials(c.business) + '</div>' +
      '      <div>' +
      '        <div class="client-name">' + escapeHTML(c.business) + '</div>' +
      '        <div class="client-contact">' + escapeHTML(c.contactName || "") + '</div>' +
      '      </div>' +
      '    </div>' +
      '  </div>' +
      '  <div class="client-meta-row">' +
      '    <span class="badge ' + statusBadge + '">' + escapeHTML(c.status || "active") + '</span>' +
      (c.entityType ? '<span class="badge b-gray">' + escapeHTML(c.entityType) + '</span>' : '') +
      (c.billingFrequency ? '<span class="badge b-teal">' + escapeHTML(c.billingFrequency) + '</span>' : '') +
      '  </div>' +
      '  <div class="client-stats-mini">' +
      '    <div><b>' + openTasks + '</b>open tasks</div>' +
      '    <div><b style="' + (overdueTasks ? 'color:var(--danger)' : '') + '">' + overdueTasks + '</b>overdue</div>' +
      '    <div><b>' + fmtMoney(unpaidTotal) + '</b>unpaid</div>' +
      '  </div>' +
      '</div>';
  }).join("");
}
