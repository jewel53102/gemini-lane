document.addEventListener("DOMContentLoaded", function () {
  initChrome("overview", "Dashboard");

  const today = todayStr();
  const clients = DB.clients.all();
  const activeClients = clients.filter(function (c) { return c.status !== "former"; });
  const tasks = DB.tasks.all().filter(function (t) { return t.status !== "done"; });
  const overdue = tasks.filter(function (t) { return t.dueDate && t.dueDate < today; });
  const weekOut = new Date(); weekOut.setDate(weekOut.getDate() + 7);
  const weekOutStr = weekOut.toISOString().slice(0, 10);
  const dueSoon = tasks.filter(function (t) { return t.dueDate && t.dueDate >= today && t.dueDate <= weekOutStr; });
  const invoices = DB.invoices.all().filter(function (i) { return i.status !== "paid"; });
  const unpaidTotal = invoices.reduce(function (sum, i) { return sum + (Number(i.amount) || 0); }, 0);

  document.getElementById("s-clients").textContent = activeClients.length;
  document.getElementById("s-overdue").textContent = overdue.length;
  document.getElementById("s-soon").textContent = dueSoon.length;
  document.getElementById("s-unpaid").textContent = fmtMoney(unpaidTotal);

  function clientName(id) {
    const c = DB.clients.get(id);
    return c ? c.business : null;
  }

  /* Due soon & overdue list */
  const dsList = document.getElementById("due-soon-list");
  const combined = overdue.concat(dueSoon).sort(function (a, b) { return (a.dueDate || "").localeCompare(b.dueDate || ""); }).slice(0, 8);
  if (combined.length === 0) {
    dsList.innerHTML = '<div class="empty"><div class="empty-ico">✅</div><div class="empty-txt">Nothing due in the next 7 days.</div></div>';
  } else {
    dsList.innerHTML = combined.map(function (t) {
      const cn = t.clientId ? clientName(t.clientId) : null;
      const dc = dueClass(t.dueDate, t.status);
      return '' +
        '<div class="task-row" style="cursor:pointer" onclick="openTaskForm(\'' + t.id + '\')">' +
        '  <div class="task-check" onclick="event.stopPropagation(); quickComplete(\'' + t.id + '\')"></div>' +
        '  <div class="task-body">' +
        '    <div class="task-title">' + escapeHTML(t.title) + '</div>' +
        '    <div class="task-meta-row">' +
        '      <span class="task-due ' + dc + '">' + dueLabel(t.dueDate, t.status) + '</span>' +
        (cn ? '<a class="task-client-tag" href="client-detail.html?id=' + t.clientId + '" onclick="event.stopPropagation()">' + escapeHTML(cn) + '</a>' : '') +
        '    </div>' +
        '  </div>' +
        '</div>';
    }).join("");
  }

  /* Clients preview */
  const cPreview = document.getElementById("clients-preview");
  if (activeClients.length === 0) {
    cPreview.innerHTML = '<div class="empty"><div class="empty-ico">👥</div><div class="empty-txt">No clients yet.</div><button class="btn btn-primary btn-sm" onclick="location.href=\'clients.html\'">Add your first client</button></div>';
  } else {
    cPreview.innerHTML = activeClients.slice(0, 6).map(function (c) {
      return '' +
        '<div class="task-row" style="cursor:pointer" onclick="location.href=\'client-detail.html?id=' + c.id + '\'">' +
        '  <div class="client-avatar" style="width:32px;height:32px;font-size:12px">' + initials(c.business) + '</div>' +
        '  <div class="task-body">' +
        '    <div class="task-title">' + escapeHTML(c.business) + '</div>' +
        '    <div class="muted">' + escapeHTML(c.contactName || "") + '</div>' +
        '  </div>' +
        '</div>';
    }).join("");
  }

  /* Invoices preview */
  const iPreview = document.getElementById("invoices-preview");
  if (invoices.length === 0) {
    iPreview.innerHTML = '<div class="empty"><div class="empty-ico">💸</div><div class="empty-txt">Nothing outstanding.</div></div>';
  } else {
    iPreview.innerHTML = invoices.sort(function (a, b) { return (a.dueDate || "").localeCompare(b.dueDate || ""); }).slice(0, 6).map(function (i) {
      const cn = i.clientId ? clientName(i.clientId) : "—";
      const overdueRow = i.dueDate && i.dueDate < today;
      return '' +
        '<div class="invoice-row">' +
        '  <span>' + escapeHTML(cn || "—") + '</span>' +
        '  <span class="muted">' + escapeHTML(i.invoiceNumber || "") + '</span>' +
        '  <span class="inv-amt">' + fmtMoney(i.amount) + '</span>' +
        '  <span class="' + (overdueRow ? "task-due overdue" : "muted") + '">' + fmtDateShort(i.dueDate) + '</span>' +
        '  <span class="badge ' + (overdueRow ? "b-red" : "b-yellow") + '">' + (overdueRow ? "Overdue" : "Unpaid") + '</span>' +
        '  <span></span>' +
        '</div>';
    }).join("");
  }
});

function quickComplete(taskId) {
  DB.tasks.update(taskId, { status: "done", completedAt: new Date().toISOString() });
  toast("Task completed");
  location.reload();
}
