/* =========================================================================
   BALANCING WITH BRITT — DATA LAYER
   Structured records (clients, tasks, templates, invoices) live
   in localStorage. Files (documents/invoices attachments) live in IndexedDB
   since localStorage can't hold binary data at any real size. Everything
   stays local to this browser — nothing is sent anywhere.
   ========================================================================= */

const LS_KEYS = {
  CLIENTS: "bwb_clients",
  TASKS: "bwb_tasks",
  TEMPLATES: "bwb_templates",
  INVOICES: "bwb_invoices",
  DOC_META: "bwb_doc_meta" // metadata for files whose blobs live in IndexedDB
};

function uid() {
  if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
  return "id-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 9);
}
function todayStr() { return new Date().toISOString().slice(0, 10); }
function loadArr(key) {
  try { const v = JSON.parse(localStorage.getItem(key) || "[]"); return Array.isArray(v) ? v : []; }
  catch (e) { return []; }
}
function saveArr(key, arr) {
  try { localStorage.setItem(key, JSON.stringify(arr)); } catch (e) { console.error("Save failed", key, e); }
}

function makeStore(key) {
  return {
    all() { return loadArr(key); },
    get(id) { return loadArr(key).find(function (r) { return r.id === id; }) || null; },
    create(obj) {
      const rec = Object.assign({ id: uid(), createdAt: new Date().toISOString() }, obj);
      const arr = loadArr(key); arr.push(rec); saveArr(key, arr);
      return rec;
    },
    update(id, patch) {
      const arr = loadArr(key);
      const idx = arr.findIndex(function (r) { return r.id === id; });
      if (idx === -1) return null;
      arr[idx] = Object.assign({}, arr[idx], patch, { updatedAt: new Date().toISOString() });
      saveArr(key, arr);
      return arr[idx];
    },
    remove(id) {
      const arr = loadArr(key).filter(function (r) { return r.id !== id; });
      saveArr(key, arr);
    }
  };
}

const DB = {
  clients: makeStore(LS_KEYS.CLIENTS),
  tasks: makeStore(LS_KEYS.TASKS),
  templates: makeStore(LS_KEYS.TEMPLATES),
  invoices: makeStore(LS_KEYS.INVOICES)
};

/* ---------- Recurring task engine ---------- */
/* A template defines a repeating task (e.g. "Monthly reconciliation").
   anchorDate is the first due date; freq steps it forward. On every page
   load we materialize actual task rows up to `horizonDays` out, so the
   to-do list always shows real, checkable, individually-editable tasks —
   not a virtual projection. */
function occurrencesUntil(anchorDate, freq, horizonDate) {
  const out = [];
  let d = new Date(anchorDate + "T00:00:00");
  const horizon = new Date(horizonDate + "T00:00:00");
  let guard = 0;
  while (d <= horizon && guard < 80) {
    out.push(d.toISOString().slice(0, 10));
    if (freq === "weekly") d.setDate(d.getDate() + 7);
    else if (freq === "monthly") d.setMonth(d.getMonth() + 1);
    else if (freq === "quarterly") d.setMonth(d.getMonth() + 3);
    else if (freq === "annual") d.setFullYear(d.getFullYear() + 1);
    else break;
    guard++;
  }
  return out;
}

function ensureRecurringInstances(horizonDays) {
  horizonDays = horizonDays || 90;
  const horizon = new Date();
  horizon.setDate(horizon.getDate() + horizonDays);
  const horizonStr = horizon.toISOString().slice(0, 10);

  const templates = DB.templates.all().filter(function (t) { return t.active !== false; });
  const existingTasks = DB.tasks.all();
  let created = 0;

  templates.forEach(function (tpl) {
    const dates = occurrencesUntil(tpl.anchorDate, tpl.freq, horizonStr);
    dates.forEach(function (dueDate) {
      const already = existingTasks.some(function (t) { return t.sourceTemplateId === tpl.id && t.dueDate === dueDate; });
      if (already) return;
      const rec = DB.tasks.create({
        title: tpl.title,
        notes: tpl.notes || "",
        clientId: tpl.clientId || null,
        category: tpl.category || "General",
        dueDate: dueDate,
        status: "open",
        priority: tpl.priority || "normal",
        sourceTemplateId: tpl.id
      });
      existingTasks.push(rec);
      created++;
    });
  });
  return created;
}

/* ---------- IndexedDB file storage ---------- */
const IDB_NAME = "bwb_files";
const IDB_STORE = "files";
let _idbPromise = null;

function idbOpen() {
  if (_idbPromise) return _idbPromise;
  _idbPromise = new Promise(function (resolve, reject) {
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = function () {
      const db = req.result;
      if (!db.objectStoreNames.contains(IDB_STORE)) {
        db.createObjectStore(IDB_STORE, { keyPath: "id" });
      }
    };
    req.onsuccess = function () { resolve(req.result); };
    req.onerror = function () { reject(req.error); };
  });
  return _idbPromise;
}

function idbPut(record) {
  return idbOpen().then(function (db) {
    return new Promise(function (resolve, reject) {
      const tx = db.transaction(IDB_STORE, "readwrite");
      tx.objectStore(IDB_STORE).put(record);
      tx.oncomplete = function () { resolve(record); };
      tx.onerror = function () { reject(tx.error); };
    });
  });
}
function idbGet(id) {
  return idbOpen().then(function (db) {
    return new Promise(function (resolve, reject) {
      const tx = db.transaction(IDB_STORE, "readonly");
      const req = tx.objectStore(IDB_STORE).get(id);
      req.onsuccess = function () { resolve(req.result || null); };
      req.onerror = function () { reject(req.error); };
    });
  });
}
function idbDelete(id) {
  return idbOpen().then(function (db) {
    return new Promise(function (resolve, reject) {
      const tx = db.transaction(IDB_STORE, "readwrite");
      tx.objectStore(IDB_STORE).delete(id);
      tx.oncomplete = function () { resolve(); };
      tx.onerror = function () { reject(tx.error); };
    });
  });
}

/* Documents: metadata (name, size, type, clientId, category, notes) lives in
   localStorage for fast listing; the actual Blob lives in IndexedDB keyed by
   the same id. */
const Docs = {
  all() { return loadArr(LS_KEYS.DOC_META); },
  get(id) { return loadArr(LS_KEYS.DOC_META).find(function (d) { return d.id === id; }) || null; },
  upload(file, meta) {
    const id = uid();
    const record = Object.assign({
      id: id, name: file.name, size: file.size, type: file.type || "application/octet-stream",
      uploadedAt: new Date().toISOString()
    }, meta);
    return idbPut({ id: id, blob: file }).then(function () {
      const arr = loadArr(LS_KEYS.DOC_META);
      arr.push(record);
      saveArr(LS_KEYS.DOC_META, arr);
      return record;
    });
  },
  updateMeta(id, patch) {
    const arr = loadArr(LS_KEYS.DOC_META);
    const idx = arr.findIndex(function (d) { return d.id === id; });
    if (idx === -1) return null;
    arr[idx] = Object.assign({}, arr[idx], patch);
    saveArr(LS_KEYS.DOC_META, arr);
    return arr[idx];
  },
  remove(id) {
    const arr = loadArr(LS_KEYS.DOC_META).filter(function (d) { return d.id !== id; });
    saveArr(LS_KEYS.DOC_META, arr);
    return idbDelete(id);
  },
  openBlob(id) {
    return idbGet(id).then(function (rec) {
      if (!rec) return null;
      const url = URL.createObjectURL(rec.blob);
      window.open(url, "_blank");
      setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
      return url;
    });
  },
  downloadBlob(id, filename) {
    return idbGet(id).then(function (rec) {
      if (!rec) return null;
      const url = URL.createObjectURL(rec.blob);
      const a = document.createElement("a");
      a.href = url; a.download = filename || rec.id;
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
    });
  }
};

/* ---------- Full backup / restore ---------- */
const BACKUP_LS_KEYS = [LS_KEYS.CLIENTS, LS_KEYS.TASKS, LS_KEYS.TEMPLATES, LS_KEYS.INVOICES, LS_KEYS.DOC_META];

function backupData() {
  const payload = { app: "balancing-with-britt-dashboard", version: 1, exportedAt: new Date().toISOString(), data: {} };
  BACKUP_LS_KEYS.forEach(function (k) { payload.data[k] = loadArr(k); });
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "balancing-with-britt-backup-" + todayStr() + ".json";
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
  if (window.toast) toast("Backup downloaded (data only — uploaded files are not included)");
}

function restoreData(file) {
  const reader = new FileReader();
  reader.onload = function () {
    let payload;
    try { payload = JSON.parse(reader.result); }
    catch (e) { toast("Restore failed — not a valid backup file"); return; }
    if (!payload || typeof payload.data !== "object") { toast("Restore failed — not a valid backup file"); return; }
    BACKUP_LS_KEYS.forEach(function (k) {
      if (payload.data[k] !== undefined) saveArr(k, payload.data[k]);
    });
    toast("Restore complete — reloading");
    setTimeout(function () { location.reload(); }, 700);
  };
  reader.onerror = function () { toast("Restore failed — could not read file"); };
  reader.readAsText(file);
}

function handleRestoreInput(input) {
  if (input.files && input.files[0]) {
    if (confirm("This will overwrite current clients, tasks and invoices with the backup file. Uploaded documents are not affected. Continue?")) {
      restoreData(input.files[0]);
    }
  }
  input.value = "";
}
