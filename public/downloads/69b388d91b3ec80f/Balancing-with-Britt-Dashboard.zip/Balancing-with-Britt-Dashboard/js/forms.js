/* =========================================================================
   BALANCING WITH BRITT — SHARED FORMS & ROW RENDERERS
   Used by tasks.html, invoices.html, documents.html and
   client-detail.html so each record type has exactly one form/one renderer.
   ========================================================================= */

function clientOptionsHTML(selectedId) {
  const clients = DB.clients.all().sort(function (a, b) { return (a.business || "").localeCompare(b.business || ""); });
  return '<option value="">— No client (internal) —</option>' + clients.map(function (c) {
    return '<option value="' + c.id + '"' + (selectedId === c.id ? " selected" : "") + '>' + escapeHTML(c.business) + '</option>';
  }).join("");
}
function clientName(id) {
  if (!id) return null;
  const c = DB.clients.get(id);
  return c ? c.business : null;
}

/* ---------- CLIENTS ---------- */
function openClientForm(clientId) {
  const c = clientId ? DB.clients.get(clientId) : null;
  const services = (c && c.services) || [];
  const title = c ? "Edit Client" : "New Client";
  const body = '' +
    '<div class="field"><label>Business Name *</label><input class="finp" id="f-business" value="' + (c ? escapeHTML(c.business) : "") + '" placeholder="e.g. Cromwell & Associates"></div>' +
    '<div class="field-row">' +
    '  <div class="field"><label>Contact Name</label><input class="finp" id="f-contact" value="' + (c ? escapeHTML(c.contactName || "") : "") + '"></div>' +
    '  <div class="field"><label>Status</label><select class="finp" id="f-status">' +
    ["active", "prospect", "former"].map(function (s) { return '<option value="' + s + '"' + (c && c.status === s ? " selected" : "") + '>' + s.charAt(0).toUpperCase() + s.slice(1) + '</option>'; }).join("") +
    '  </select></div>' +
    '</div>' +
    '<div class="field-row">' +
    '  <div class="field"><label>Email</label><input class="finp" id="f-email" value="' + (c ? escapeHTML(c.email || "") : "") + '"></div>' +
    '  <div class="field"><label>Phone</label><input class="finp" id="f-phone" value="' + (c ? escapeHTML(c.phone || "") : "") + '"></div>' +
    '</div>' +
    '<div class="field-row">' +
    '  <div class="field"><label>Entity Type</label><select class="finp" id="f-entity"><option value="">—</option>' +
    ENTITY_TYPES.map(function (e) { return '<option' + (c && c.entityType === e ? " selected" : "") + '>' + e + '</option>'; }).join("") +
    '  </select></div>' +
    '  <div class="field"><label>Billing Frequency</label><select class="finp" id="f-freq"><option value="">—</option>' +
    BILLING_FREQS.map(function (f) { return '<option' + (c && c.billingFrequency === f ? " selected" : "") + '>' + f + '</option>'; }).join("") +
    '  </select></div>' +
    '</div>' +
    '<div class="field-row">' +
    '  <div class="field"><label>Rate ($)</label><input class="finp" id="f-rate" type="number" step="0.01" value="' + (c ? (c.rate || "") : "") + '"></div>' +
    '  <div class="field"><label>Bookkeeping Software</label><input class="finp" id="f-software" value="' + (c ? escapeHTML(c.softwareUsed || "") : "") + '" placeholder="e.g. QuickBooks Online"></div>' +
    '</div>' +
    '<div class="field"><label>Services Provided</label><div class="flex fw gap-8">' +
    SERVICE_OPTIONS.map(function (s) {
      const checked = services.indexOf(s) > -1 ? " checked" : "";
      return '<label class="badge b-gray" style="cursor:pointer;gap:5px;display:inline-flex;align-items:center"><input type="checkbox" class="f-service" value="' + s + '"' + checked + ' style="margin:0">' + s + '</label>';
    }).join("") +
    '</div></div>' +
    '<div class="field"><label>Start Date</label><input class="finp" id="f-start" type="date" value="' + (c ? (c.startDate || "") : "") + '"></div>' +
    '<div class="field"><label>Logins &amp; Passwords</label><textarea class="finp" id="f-logininfo" placeholder="e.g. QuickBooks Online — user: jane@... / pass: ...&#10;Bank portal — user: ... / pass: ...">' + (c ? escapeHTML(c.loginInfo || "") : "") + '</textarea><div class="field-hint">Stored as plain text in this browser only — not encrypted. Fine for local use, not a substitute for a real password manager if this file is ever shared or hosted.</div></div>' +
    '<div class="field"><label>Notes</label><textarea class="finp" id="f-notes">' + (c ? escapeHTML(c.notes || "") : "") + '</textarea></div>';
  const footer = '' +
    (c ? '<button class="btn btn-danger" onclick="deleteClient(\'' + c.id + '\')">Delete</button>' : '') +
    '<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>' +
    '<button class="btn btn-primary" onclick="saveClient(' + (c ? "'" + c.id + "'" : "null") + ')">Save Client</button>';
  openModal(title, body, footer);
}

function saveClient(clientId) {
  const business = document.getElementById("f-business").value.trim();
  if (!business) { toast("Business name is required"); return; }
  const services = Array.from(document.querySelectorAll(".f-service:checked")).map(function (el) { return el.value; });
  const patch = {
    business: business,
    contactName: document.getElementById("f-contact").value.trim(),
    status: document.getElementById("f-status").value,
    email: document.getElementById("f-email").value.trim(),
    phone: document.getElementById("f-phone").value.trim(),
    entityType: document.getElementById("f-entity").value,
    billingFrequency: document.getElementById("f-freq").value,
    rate: parseFloat(document.getElementById("f-rate").value) || 0,
    softwareUsed: document.getElementById("f-software").value.trim(),
    services: services,
    startDate: document.getElementById("f-start").value,
    loginInfo: document.getElementById("f-logininfo").value,
    notes: document.getElementById("f-notes").value.trim()
  };
  if (clientId) DB.clients.update(clientId, patch);
  else DB.clients.create(patch);
  closeModal();
  toast("Client saved");
  if (window.__rerenderPage) window.__rerenderPage(); else location.reload();
}

function deleteClient(clientId) {
  if (!confirm("Delete this client? Their saved logins/passwords go with them. Tasks, invoices and documents will remain but be unlinked from any client.")) return;
  DB.clients.remove(clientId);
  closeModal();
  toast("Client deleted");
  location.href = "clients.html";
}

/* ---------- TASKS ---------- */
function renderTaskRow(t, opts) {
  opts = opts || {};
  const cn = t.clientId ? clientName(t.clientId) : null;
  const dc = dueClass(t.dueDate, t.status);
  const isDone = t.status === "done";
  return '' +
    '<div class="task-row" data-id="' + t.id + '">' +
    '  <div class="task-check' + (isDone ? " done" : "") + '" onclick="toggleTaskDone(\'' + t.id + '\')">' + (isDone ? "✓" : "") + '</div>' +
    '  <div class="task-body">' +
    '    <div class="task-title' + (isDone ? " done" : "") + '">' + escapeHTML(t.title) + '</div>' +
    '    <div class="task-meta-row">' +
    '      <span class="task-due ' + dc + '">' + dueLabel(t.dueDate, t.status) + '</span>' +
    (t.category ? '<span class="badge b-gray">' + escapeHTML(t.category) + '</span>' : '') +
    (t.priority === "high" ? '<span class="badge b-red">High</span>' : '') +
    (t.sourceTemplateId ? '<span class="badge b-teal">Recurring</span>' : '') +
    (!opts.hideClient && cn ? '<a class="task-client-tag" href="client-detail.html?id=' + t.clientId + '">' + escapeHTML(cn) + '</a>' : '') +
    '    </div>' +
    (t.notes ? '<div class="muted mt-8">' + escapeHTML(t.notes) + '</div>' : '') +
    '  </div>' +
    '  <div class="task-actions">' +
    '    <button class="btn btn-ghost btn-icon btn-sm" onclick="openTaskForm(\'' + t.id + '\')" title="Edit">✎</button>' +
    '    <button class="btn btn-ghost btn-icon btn-sm" onclick="deleteTask(\'' + t.id + '\')" title="Delete">🗑</button>' +
    '  </div>' +
    '</div>';
}

function toggleTaskDone(taskId) {
  const t = DB.tasks.get(taskId);
  if (!t) return;
  DB.tasks.update(taskId, { status: t.status === "done" ? "open" : "done", completedAt: t.status === "done" ? null : new Date().toISOString() });
  if (window.__rerenderPage) window.__rerenderPage(); else location.reload();
}

function openTaskForm(taskId, defaultClientId) {
  const t = taskId ? DB.tasks.get(taskId) : null;
  const title = t ? "Edit Task" : "New Task";
  const body = '' +
    '<div class="field"><label>Task *</label><input class="finp" id="f-title" value="' + (t ? escapeHTML(t.title) : "") + '" placeholder="e.g. Reconcile October bank statement"></div>' +
    '<div class="field-row">' +
    '  <div class="field"><label>Client</label><select class="finp" id="f-client">' + clientOptionsHTML(t ? t.clientId : defaultClientId) + '</select></div>' +
    '  <div class="field"><label>Category</label><select class="finp" id="f-category">' +
    TASK_CATEGORIES.map(function (c) { return '<option' + (t && t.category === c ? " selected" : "") + '>' + c + '</option>'; }).join("") +
    '  </select></div>' +
    '</div>' +
    '<div class="field-row">' +
    '  <div class="field"><label>Due Date</label><input class="finp" id="f-due" type="date" value="' + (t ? (t.dueDate || "") : "") + '"></div>' +
    '  <div class="field"><label>Priority</label><select class="finp" id="f-priority">' +
    ["normal", "high"].map(function (p) { return '<option value="' + p + '"' + (t && t.priority === p ? " selected" : "") + '>' + (p === "high" ? "High" : "Normal") + '</option>'; }).join("") +
    '  </select></div>' +
    '</div>' +
    '<div class="field"><label>Notes</label><textarea class="finp" id="f-notes">' + (t ? escapeHTML(t.notes || "") : "") + '</textarea></div>' +
    (t && t.sourceTemplateId ? '<div class="notice info"><span class="notice-ico">🔁</span><span>This task was generated from a recurring template. Editing it only changes this occurrence.</span></div>' : "");
  const footer = '' +
    (t ? '<button class="btn btn-danger" onclick="deleteTask(\'' + t.id + '\')">Delete</button>' : '') +
    '<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>' +
    '<button class="btn btn-primary" onclick="saveTask(' + (t ? "'" + t.id + "'" : "null") + ')">Save Task</button>';
  openModal(title, body, footer);
}

function saveTask(taskId) {
  const title = document.getElementById("f-title").value.trim();
  if (!title) { toast("Task name is required"); return; }
  const patch = {
    title: title,
    clientId: document.getElementById("f-client").value || null,
    category: document.getElementById("f-category").value,
    dueDate: document.getElementById("f-due").value,
    priority: document.getElementById("f-priority").value,
    notes: document.getElementById("f-notes").value.trim()
  };
  if (taskId) DB.tasks.update(taskId, patch);
  else DB.tasks.create(Object.assign({ status: "open" }, patch));
  closeModal();
  toast("Task saved");
  if (window.__rerenderPage) window.__rerenderPage(); else location.reload();
}

function deleteTask(taskId) {
  if (!confirm("Delete this task?")) return;
  DB.tasks.remove(taskId);
  closeModal();
  toast("Task deleted");
  if (window.__rerenderPage) window.__rerenderPage(); else location.reload();
}

/* ---------- RECURRING TEMPLATES ---------- */
function openTemplateForm(templateId, defaultClientId) {
  const tpl = templateId ? DB.templates.get(templateId) : null;
  const title = tpl ? "Edit Recurring Task" : "New Recurring Task";
  const body = '' +
    '<div class="field"><label>Task *</label><input class="finp" id="f-title" value="' + (tpl ? escapeHTML(tpl.title) : "") + '" placeholder="e.g. Monthly reconciliation"></div>' +
    '<div class="field-row">' +
    '  <div class="field"><label>Client</label><select class="finp" id="f-client">' + clientOptionsHTML(tpl ? tpl.clientId : defaultClientId) + '</select></div>' +
    '  <div class="field"><label>Category</label><select class="finp" id="f-category">' +
    TASK_CATEGORIES.map(function (c) { return '<option' + (tpl && tpl.category === c ? " selected" : "") + '>' + c + '</option>'; }).join("") +
    '  </select></div>' +
    '</div>' +
    '<div class="field-row">' +
    '  <div class="field"><label>Repeats</label><select class="finp" id="f-freq">' +
    [["weekly", "Weekly"], ["biweekly", "Bi-Weekly"], ["monthly", "Monthly"], ["quarterly", "Quarterly"], ["annual", "Annual"]].map(function (f) {
      return '<option value="' + f[0] + '"' + (tpl && tpl.freq === f[0] ? " selected" : "") + '>' + f[1] + '</option>';
    }).join("") +
    '  </select></div>' +
    '  <div class="field"><label>First Due Date *</label><input class="finp" id="f-anchor" type="date" value="' + (tpl ? tpl.anchorDate : todayStr()) + '"></div>' +
    '</div>' +
    '<div class="field"><label>Notes</label><textarea class="finp" id="f-notes">' + (tpl ? escapeHTML(tpl.notes || "") : "") + '</textarea></div>' +
    '<div class="notice info"><span class="notice-ico">🔁</span><span>This creates a repeating task series. Instances are generated automatically up to 90 days ahead, and each one can be checked off, edited or deleted individually.</span></div>';
  const footer = '' +
    (tpl ? '<button class="btn btn-danger" onclick="deleteTemplate(\'' + tpl.id + '\')">Delete Series</button>' : '') +
    '<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>' +
    '<button class="btn btn-primary" onclick="saveTemplate(' + (tpl ? "'" + tpl.id + "'" : "null") + ')">Save</button>';
  openModal(title, body, footer);
}

function saveTemplate(templateId) {
  const title = document.getElementById("f-title").value.trim();
  const anchorDate = document.getElementById("f-anchor").value;
  if (!title) { toast("Task name is required"); return; }
  if (!anchorDate) { toast("First due date is required"); return; }
  const patch = {
    title: title,
    clientId: document.getElementById("f-client").value || null,
    category: document.getElementById("f-category").value,
    freq: document.getElementById("f-freq").value,
    anchorDate: anchorDate,
    notes: document.getElementById("f-notes").value.trim(),
    active: true
  };
  if (templateId) DB.templates.update(templateId, patch);
  else DB.templates.create(patch);
  ensureRecurringInstances();
  closeModal();
  toast("Recurring task saved");
  if (window.__rerenderPage) window.__rerenderPage(); else location.reload();
}

function deleteTemplate(templateId) {
  if (!confirm("Delete this recurring series? Past/generated task instances stay, but no new ones will be created.")) return;
  DB.templates.remove(templateId);
  closeModal();
  toast("Recurring series deleted");
  if (window.__rerenderPage) window.__rerenderPage(); else location.reload();
}

/* ---------- INVOICES ---------- */
function renderInvoiceRow(i, opts) {
  opts = opts || {};
  const cn = i.clientId ? clientName(i.clientId) : null;
  const today = todayStr();
  const overdue = i.status !== "paid" && i.dueDate && i.dueDate < today;
  const statusBadge = i.status === "paid" ? "b-green" : overdue ? "b-red" : i.status === "sent" ? "b-blue" : "b-gray";
  const statusLabel = i.status === "paid" ? "Paid" : overdue ? "Overdue" : i.status === "sent" ? "Sent" : "Draft";
  return '' +
    '<div class="invoice-row" data-id="' + i.id + '">' +
    '  <span>' + (opts.hideClient ? escapeHTML(i.invoiceNumber || "—") : (cn ? '<a href="client-detail.html?id=' + i.clientId + '" class="task-client-tag">' + escapeHTML(cn) + '</a>' : '—')) + '</span>' +
    '  <span class="muted">' + (opts.hideClient ? escapeHTML(i.notes || "") : escapeHTML(i.invoiceNumber || "")) + '</span>' +
    '  <span class="inv-amt">' + fmtMoney(i.amount) + '</span>' +
    '  <span class="' + (overdue ? "task-due overdue" : "muted") + '">' + fmtDateShort(i.dueDate) + '</span>' +
    '  <span class="badge ' + statusBadge + '">' + statusLabel + '</span>' +
    '  <span class="task-actions" style="opacity:1">' +
    (i.status !== "paid" ? '<button class="btn btn-ghost btn-icon btn-sm" onclick="markInvoicePaid(\'' + i.id + '\')" title="Mark Paid">✓</button>' : '') +
    '    <button class="btn btn-ghost btn-icon btn-sm" onclick="downloadInvoicePDF(\'' + i.id + '\')" title="Download PDF">📄</button>' +
    '    <button class="btn btn-ghost btn-icon btn-sm" onclick="openInvoiceForm(\'' + i.id + '\')" title="Edit">✎</button>' +
    '  </span>' +
    '</div>';
}

function openInvoiceForm(invoiceId, defaultClientId) {
  const i = invoiceId ? DB.invoices.get(invoiceId) : null;
  const title = i ? "Edit Invoice" : "New Invoice";
  const body = '' +
    '<div class="field-row">' +
    '  <div class="field"><label>Client</label><select class="finp" id="f-client">' + clientOptionsHTML(i ? i.clientId : defaultClientId) + '</select></div>' +
    '  <div class="field"><label>Invoice #</label><input class="finp" id="f-num" value="' + (i ? escapeHTML(i.invoiceNumber || "") : "") + '" placeholder="e.g. 1042"></div>' +
    '</div>' +
    '<div class="field-row">' +
    '  <div class="field"><label>Amount ($) *</label><input class="finp" id="f-amount" type="number" step="0.01" value="' + (i ? i.amount : "") + '"></div>' +
    '  <div class="field"><label>Status</label><select class="finp" id="f-status">' +
    [["draft", "Draft"], ["sent", "Sent"], ["paid", "Paid"]].map(function (s) { return '<option value="' + s[0] + '"' + (i && i.status === s[0] ? " selected" : "") + '>' + s[1] + '</option>'; }).join("") +
    '  </select></div>' +
    '</div>' +
    '<div class="field-row">' +
    '  <div class="field"><label>Issue Date</label><input class="finp" id="f-issue" type="date" value="' + (i ? (i.issueDate || "") : todayStr()) + '"></div>' +
    '  <div class="field"><label>Due Date</label><input class="finp" id="f-due" type="date" value="' + (i ? (i.dueDate || "") : "") + '"></div>' +
    '</div>' +
    '<div class="field"><label>Notes</label><textarea class="finp" id="f-notes">' + (i ? escapeHTML(i.notes || "") : "") + '</textarea></div>';
  const footer = '' +
    (i ? '<button class="btn btn-danger" onclick="deleteInvoice(\'' + i.id + '\')">Delete</button>' : '') +
    '<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>' +
    '<button class="btn btn-primary" onclick="saveInvoice(' + (i ? "'" + i.id + "'" : "null") + ')">Save Invoice</button>';
  openModal(title, body, footer);
}

function saveInvoice(invoiceId) {
  const amount = parseFloat(document.getElementById("f-amount").value);
  if (!amount || amount <= 0) { toast("Enter a valid amount"); return; }
  const patch = {
    clientId: document.getElementById("f-client").value || null,
    invoiceNumber: document.getElementById("f-num").value.trim(),
    amount: amount,
    status: document.getElementById("f-status").value,
    issueDate: document.getElementById("f-issue").value,
    dueDate: document.getElementById("f-due").value,
    notes: document.getElementById("f-notes").value.trim()
  };
  if (invoiceId) DB.invoices.update(invoiceId, patch);
  else DB.invoices.create(patch);
  closeModal();
  toast("Invoice saved");
  if (window.__rerenderPage) window.__rerenderPage(); else location.reload();
}

function markInvoicePaid(invoiceId) {
  DB.invoices.update(invoiceId, { status: "paid", paidAt: new Date().toISOString() });
  toast("Marked paid");
  if (window.__rerenderPage) window.__rerenderPage(); else location.reload();
}

function deleteInvoice(invoiceId) {
  if (!confirm("Delete this invoice?")) return;
  DB.invoices.remove(invoiceId);
  closeModal();
  toast("Invoice deleted");
  if (window.__rerenderPage) window.__rerenderPage(); else location.reload();
}

function downloadInvoicePDF(invoiceId) {
  const i = DB.invoices.get(invoiceId);
  if (!i) { toast("Invoice not found"); return; }
  const c = i.clientId ? DB.clients.get(i.clientId) : null;
  const num = i.invoiceNumber || i.id.slice(0, 8);
  const statusLabel = i.status === "paid" ? "Paid" : i.status === "sent" ? "Sent" : "Draft";

  const win = window.open("", "_blank");
  if (!win) { toast("Please allow pop-ups to download the invoice"); return; }

  win.document.title = "Invoice " + num;
  win.document.write('' +
    '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Invoice ' + escapeHTML(num) + '</title>' +
    '<style>' +
    '  @page { margin: 0.75in; }' +
    '  body { font-family: -apple-system, Arial, sans-serif; color: #1a1a1a; margin: 0; }' +
    '  .inv-head { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #1a1a1a; padding-bottom: 16px; margin-bottom: 24px; }' +
    '  .inv-head h1 { margin: 0; font-size: 22px; }' +
    '  .inv-head .sub { color: #666; font-size: 13px; margin-top: 4px; }' +
    '  .inv-title { text-align: right; }' +
    '  .inv-title .label { font-size: 26px; font-weight: 700; letter-spacing: 1px; }' +
    '  .inv-title .num { color: #666; font-size: 13px; margin-top: 4px; }' +
    '  .inv-meta { display: flex; justify-content: space-between; margin-bottom: 28px; }' +
    '  .inv-meta .block h3 { font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; color: #888; margin: 0 0 6px; }' +
    '  .inv-meta .block div { font-size: 14px; line-height: 1.5; }' +
    '  table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }' +
    '  th { text-align: left; font-size: 11px; text-transform: uppercase; color: #888; border-bottom: 2px solid #1a1a1a; padding: 8px 0; }' +
    '  td { padding: 14px 0; border-bottom: 1px solid #ddd; font-size: 14px; }' +
    '  .amt-col { text-align: right; }' +
    '  .totals { display: flex; justify-content: flex-end; }' +
    '  .totals .row { width: 240px; display: flex; justify-content: space-between; font-size: 15px; padding: 6px 0; }' +
    '  .totals .row.total { font-weight: 700; font-size: 18px; border-top: 2px solid #1a1a1a; margin-top: 6px; padding-top: 10px; }' +
    '  .status-tag { display: inline-block; padding: 3px 10px; border-radius: 4px; font-size: 12px; font-weight: 600; margin-top: 10px; }' +
    '  .status-paid { background: #d1fae5; color: #047857; }' +
    '  .status-sent { background: #dbeafe; color: #1d4ed8; }' +
    '  .status-draft { background: #f1f1f1; color: #555; }' +
    '  .notes { margin-top: 24px; font-size: 13px; color: #444; }' +
    '  .notes h3 { font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; color: #888; margin: 0 0 6px; }' +
    '  .foot { margin-top: 48px; text-align: center; color: #999; font-size: 12px; }' +
    '</style></head><body>' +
    '  <div class="inv-head">' +
    '    <div><h1>Balancing with Britt, LLC</h1><div class="sub">Bookkeeping &amp; Financial Services</div></div>' +
    '    <div class="inv-title"><div class="label">INVOICE</div><div class="num"># ' + escapeHTML(num) + '</div>' +
    '      <div class="status-tag status-' + i.status + '">' + statusLabel + '</div>' +
    '    </div>' +
    '  </div>' +
    '  <div class="inv-meta">' +
    '    <div class="block"><h3>Bill To</h3><div>' +
    (c ? escapeHTML(c.business) + (c.contactName ? '<br>' + escapeHTML(c.contactName) : "") + (c.email ? '<br>' + escapeHTML(c.email) : "") + (c.phone ? '<br>' + escapeHTML(c.phone) : "") : "—") +
    '    </div></div>' +
    '    <div class="block"><h3>Invoice Details</h3><div>' +
    'Issue Date: ' + (i.issueDate ? escapeHTML(fmtDate(i.issueDate)) : "—") + '<br>' +
    'Due Date: ' + (i.dueDate ? escapeHTML(fmtDate(i.dueDate)) : "—") +
    '    </div></div>' +
    '  </div>' +
    '  <table>' +
    '    <thead><tr><th>Description</th><th class="amt-col">Amount</th></tr></thead>' +
    '    <tbody><tr><td>' + escapeHTML(i.notes || "Professional services") + '</td><td class="amt-col">' + fmtMoney(i.amount) + '</td></tr></tbody>' +
    '  </table>' +
    '  <div class="totals"><div class="row total"><span>Total Due</span><span>' + fmtMoney(i.amount) + '</span></div></div>' +
    '  <div class="foot">Thank you for your business!</div>' +
    '</body></html>');
  win.document.close();
  win.focus();
  win.print();
}

/* ---------- DOCUMENTS ---------- */
function renderDocCard(d, opts) {
  opts = opts || {};
  const cn = d.clientId ? clientName(d.clientId) : null;
  return '' +
    '<div class="doc-card" data-id="' + d.id + '">' +
    '  <div class="doc-card-top">' +
    '    <div class="doc-ico">' + fileIcon(d.type) + '</div>' +
    '    <div style="min-width:0"><div class="doc-name">' + escapeHTML(d.name) + '</div><div class="doc-meta">' + fmtBytes(d.size) + ' · ' + fmtDateShort(d.uploadedAt.slice(0, 10)) + '</div></div>' +
    '  </div>' +
    '  <div class="client-meta-row mb-8">' +
    (d.category ? '<span class="badge b-gray">' + escapeHTML(d.category) + '</span>' : '') +
    (!opts.hideClient && cn ? '<a class="task-client-tag" href="client-detail.html?id=' + d.clientId + '">' + escapeHTML(cn) + '</a>' : '') +
    '  </div>' +
    (d.notes ? '<div class="doc-desc">' + escapeHTML(d.notes) + '</div>' : '') +
    '  <div class="doc-actions">' +
    '    <button class="btn btn-ghost btn-sm" onclick="Docs.openBlob(\'' + d.id + '\')">Open</button>' +
    '    <button class="btn btn-ghost btn-sm" onclick="Docs.downloadBlob(\'' + d.id + '\', \'' + escapeHTML(d.name).replace(/'/g, "\\'") + '\')">↓</button>' +
    '    <button class="btn btn-ghost btn-sm" onclick="editDocumentMeta(\'' + d.id + '\')">✎</button>' +
    '    <button class="btn btn-danger btn-sm" onclick="deleteDocument(\'' + d.id + '\')">🗑</button>' +
    '  </div>' +
    '</div>';
}

/* Downloads every uploaded file's actual content one at a time (optionally
   scoped to one client). The JSON backup only carries file metadata — the
   blobs live in IndexedDB and never leave the browser on their own — so this
   is the only way to get real copies of documents onto disk. */
function downloadAllFiles(clientIdFilter) {
  let docs = Docs.all();
  if (clientIdFilter) docs = docs.filter(function (d) { return d.clientId === clientIdFilter; });
  if (docs.length === 0) { toast("No documents to download"); return; }
  if (!confirm("Download " + docs.length + " file(s) to your Downloads folder? Your browser may ask you to allow multiple downloads.")) return;
  docs.forEach(function (d, i) {
    setTimeout(function () {
      const cn = d.clientId ? clientName(d.clientId) : "Internal";
      const safeName = (clientIdFilter ? "" : cn + " - ") + d.name;
      Docs.downloadBlob(d.id, safeName);
    }, i * 300);
  });
  toast("Downloading " + docs.length + " file(s)…");
}

function editDocumentMeta(docId) {
  const d = Docs.get(docId);
  if (!d) return;
  const body = '' +
    '<div class="field"><label>File Name</label><input class="finp" id="f-name" value="' + escapeHTML(d.name) + '"></div>' +
    '<div class="field"><label>Client</label><select class="finp" id="f-client">' + clientOptionsHTML(d.clientId) + '</select></div>' +
    '<div class="field"><label>Category</label><select class="finp" id="f-category">' +
    DOC_CATEGORIES.map(function (c) { return '<option' + (d.category === c ? " selected" : "") + '>' + c + '</option>'; }).join("") +
    '</select></div>' +
    '<div class="field"><label>Notes</label><textarea class="finp" id="f-notes">' + escapeHTML(d.notes || "") + '</textarea></div>';
  const footer = '' +
    '<button class="btn btn-danger" onclick="deleteDocument(\'' + d.id + '\')">Delete</button>' +
    '<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>' +
    '<button class="btn btn-primary" onclick="saveDocumentMeta(\'' + d.id + '\')">Save</button>';
  openModal("Edit Document", body, footer);
}

function saveDocumentMeta(docId) {
  Docs.updateMeta(docId, {
    name: document.getElementById("f-name").value.trim(),
    clientId: document.getElementById("f-client").value || null,
    category: document.getElementById("f-category").value,
    notes: document.getElementById("f-notes").value.trim()
  });
  closeModal();
  toast("Document updated");
  if (window.__rerenderPage) window.__rerenderPage(); else location.reload();
}

function deleteDocument(docId) {
  if (!confirm("Delete this file? This cannot be undone.")) return;
  Docs.remove(docId).then(function () {
    closeModal();
    toast("Document deleted");
    if (window.__rerenderPage) window.__rerenderPage(); else location.reload();
  });
}

function openUploadForm(defaultClientId) {
  const body = '' +
    '<div class="field"><label>File *</label><input class="finp" id="f-file" type="file"></div>' +
    '<div class="field"><label>Client</label><select class="finp" id="f-client">' + clientOptionsHTML(defaultClientId) + '</select></div>' +
    '<div class="field"><label>Category</label><select class="finp" id="f-category">' +
    DOC_CATEGORIES.map(function (c) { return '<option>' + c + '</option>'; }).join("") +
    '</select></div>' +
    '<div class="field"><label>Notes</label><textarea class="finp" id="f-notes" placeholder="Optional description"></textarea></div>';
  const footer = '' +
    '<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>' +
    '<button class="btn btn-primary" onclick="submitUpload()">Upload</button>';
  openModal("Upload Document", body, footer);
}

function submitUpload() {
  const fileInput = document.getElementById("f-file");
  const file = fileInput.files[0];
  if (!file) { toast("Choose a file first"); return; }
  const meta = {
    clientId: document.getElementById("f-client").value || null,
    category: document.getElementById("f-category").value,
    notes: document.getElementById("f-notes").value.trim()
  };
  Docs.upload(file, meta).then(function () {
    closeModal();
    toast("Uploaded");
    if (window.__rerenderPage) window.__rerenderPage(); else location.reload();
  }).catch(function (e) {
    console.error(e);
    toast("Upload failed");
  });
}

function handleDroppedFiles(files, defaultClientId) {
  if (!files || !files.length) return;
  Array.from(files).forEach(function (file) {
    Docs.upload(file, { clientId: defaultClientId || null, category: "Other", notes: "" });
  });
  setTimeout(function () {
    toast(files.length + " file(s) uploaded");
    if (window.__rerenderPage) window.__rerenderPage(); else location.reload();
  }, 200);
}
