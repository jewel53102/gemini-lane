/* =========================================================================
   BALANCING WITH BRITT — SHARED CHROME
   Sidebar, topbar, modal system, toast, formatting helpers.
   ========================================================================= */

const SERVICE_OPTIONS = ["Bookkeeping", "Payroll", "Accounts Payable", "Accounts Receivable", "Bank Reconciliation", "Tax Preparation", "Sales Tax Filing", "Financial Reporting", "Bill Pay", "Budgeting/Forecasting"];
const ENTITY_TYPES = ["Sole Proprietorship", "Single-Member LLC", "Multi-Member LLC", "S-Corp", "C-Corp", "Partnership", "Nonprofit"];
const BILLING_FREQS = ["Weekly", "Bi-Weekly", "Monthly", "Quarterly", "Annual", "Project-Based", "Hourly"];
const TASK_CATEGORIES = ["General", "Reconciliation", "Payroll", "Tax Filing", "Financial Reporting", "AP/AR", "Onboarding", "Client Communication"];
const DOC_CATEGORIES = ["Tax Documents", "Financial Statements", "Bank/Card Statements", "Contracts & Agreements", "Payroll Records", "Receipts", "Invoices", "Other"];

function fmtMoney(n) {
  n = Number(n) || 0;
  return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function fmtDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso + "T00:00:00");
  if (isNaN(d)) return iso;
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}
function fmtDateShort(iso) {
  if (!iso) return "—";
  const d = new Date(iso + "T00:00:00");
  if (isNaN(d)) return iso;
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}
function daysUntil(iso) {
  if (!iso) return null;
  const d = new Date(iso + "T00:00:00");
  const t = new Date(); t.setHours(0, 0, 0, 0);
  return Math.round((d - t) / 86400000);
}
function dueClass(iso, status) {
  if (status === "done" || status === "paid") return "";
  const du = daysUntil(iso);
  if (du === null) return "";
  if (du < 0) return "overdue";
  if (du <= 3) return "soon";
  return "";
}
function dueLabel(iso, status) {
  if (!iso) return "No due date";
  const du = daysUntil(iso);
  const base = fmtDate(iso);
  if (status === "done" || status === "paid") return base;
  if (du < 0) return base + " · " + Math.abs(du) + "d overdue";
  if (du === 0) return base + " · Today";
  if (du === 1) return base + " · Tomorrow";
  if (du <= 7) return base + " · " + du + "d";
  return base;
}
function escapeHTML(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
  });
}
function initials(name) {
  if (!name) return "?";
  const parts = name.trim().split(/\s+/);
  return ((parts[0] || "")[0] + (parts.length > 1 ? parts[parts.length - 1][0] : "")).toUpperCase();
}
function fileIcon(type) {
  if (!type) return "📄";
  if (type.indexOf("pdf") > -1) return "📕";
  if (type.indexOf("image") > -1) return "🖼️";
  if (type.indexOf("sheet") > -1 || type.indexOf("excel") > -1 || type.indexOf("csv") > -1) return "📊";
  if (type.indexOf("word") > -1 || type.indexOf("document") > -1) return "📝";
  if (type.indexOf("zip") > -1) return "🗜️";
  return "📄";
}
function fmtBytes(n) {
  if (!n && n !== 0) return "";
  if (n < 1024) return n + " B";
  if (n < 1024 * 1024) return (n / 1024).toFixed(0) + " KB";
  return (n / (1024 * 1024)).toFixed(1) + " MB";
}

/* ---------- Toast ---------- */
function toast(msg) {
  const t = document.getElementById("toast");
  if (!t) return;
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(function () { t.classList.remove("show"); }, 2400);
}

/* ---------- Modal ---------- */
function openModal(titleHTML, bodyHTML, footerHTML) {
  let backdrop = document.getElementById("modal-backdrop");
  if (!backdrop) {
    backdrop = document.createElement("div");
    backdrop.id = "modal-backdrop";
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML =
      '<div class="modal">' +
      '  <div class="modal-hd"><span class="modal-title" id="modal-title"></span><button class="modal-close" onclick="closeModal()">&times;</button></div>' +
      '  <div class="modal-body" id="modal-body"></div>' +
      '  <div class="modal-ft" id="modal-ft"></div>' +
      '</div>';
    document.body.appendChild(backdrop);
    backdrop.addEventListener("click", function (e) { if (e.target === backdrop) closeModal(); });
  }
  document.getElementById("modal-title").innerHTML = titleHTML;
  document.getElementById("modal-body").innerHTML = bodyHTML;
  document.getElementById("modal-ft").innerHTML = footerHTML || "";
  backdrop.classList.add("open");
}
function closeModal() {
  const backdrop = document.getElementById("modal-backdrop");
  if (backdrop) backdrop.classList.remove("open");
}
document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeModal(); });

/* ---------- Sidebar / topbar chrome ---------- */
function initChrome(activePage, title, sub) {
  ensureRecurringInstances();

  const dateEl = document.getElementById("topbar-date");
  if (dateEl) dateEl.textContent = new Date().toLocaleDateString(undefined, { weekday: "long", year: "numeric", month: "long", day: "numeric" });

  const t = document.getElementById("topbar-title");
  if (t) t.textContent = title || "";
  const s = document.getElementById("topbar-sub");
  if (s) { s.textContent = sub || ""; s.style.display = sub ? "" : "none"; }

  mountSidebar(activePage);

  if (!document.getElementById("toast")) {
    const el = document.createElement("div");
    el.id = "toast";
    document.body.appendChild(el);
  }
}

function urgentTaskCount() {
  const today = todayStr();
  return DB.tasks.all().filter(function (t) {
    return t.status !== "done" && t.dueDate && t.dueDate <= today;
  }).length;
}
function unpaidInvoiceCount() {
  return DB.invoices.all().filter(function (i) { return i.status !== "paid"; }).length;
}
function activeClientCount() {
  return DB.clients.all().filter(function (c) { return c.status !== "former"; }).length;
}

function sidebarHTML(active) {
  function item(page, href, label, icon, count) {
    const cls = "sb-item" + (page === active ? " active" : "");
    const countHTML = count ? '<span class="sb-count">' + count + '</span>' : "";
    return '<a class="' + cls + '" href="' + href + '" data-page="' + page + '">' + icon + label + countHTML + '</a>';
  }
  const ico = {
    overview: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1.5" stroke-width="2"/><rect x="14" y="3" width="7" height="7" rx="1.5" stroke-width="2"/><rect x="3" y="14" width="7" height="7" rx="1.5" stroke-width="2"/><rect x="14" y="14" width="7" height="7" rx="1.5" stroke-width="2"/></svg>',
    clients: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-5.13a4 4 0 11-8 0 4 4 0 018 0zm6 0a4 4 0 11-8 0 4 4 0 018 0z"/></svg>',
    tasks: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>',
    invoices: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>',
    documents: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5.5C4 4.67 4.67 4 5.5 4H11a2 2 0 012 2v14a2 2 0 00-2-2H4V5.5zM20 5.5c0-.83-.67-1.5-1.5-1.5H13a2 2 0 00-2 2v14a2 2 0 012-2h7V5.5z"/></svg>',
    guide: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>'
  };
  return '' +
    '<aside class="sidebar">' +
    '  <div class="sb-brand"><div class="sb-logo">Balancing with Britt</div><div class="sb-sub">Practice Command Center</div></div>' +
    '  <nav class="sb-nav">' +
    '    <div class="sb-label">Overview</div>' +
    item("overview", "index.html", "Dashboard", ico.overview) +
    '    <div class="sb-label" style="margin-top:14px">Practice</div>' +
    item("clients", "clients.html", "Clients", ico.clients, activeClientCount()) +
    item("tasks", "tasks.html", "To-Do List", ico.tasks, urgentTaskCount()) +
    item("invoices", "invoices.html", "Invoices", ico.invoices, unpaidInvoiceCount()) +
    item("documents", "documents.html", "Documents", ico.documents) +
    '    <div class="sb-label" style="margin-top:14px">Help</div>' +
    item("guide", "How-To-Guide.html", "How-To Guide", ico.guide) +
    '  </nav>' +
    '  <div class="sb-actions">' +
    '    <button class="sb-action-btn" onclick="backupData()" title="Download a backup of your data (not uploaded files)">&#8681; Backup</button>' +
    '    <button class="sb-action-btn" onclick="document.getElementById(\'sb-restore-input\').click()" title="Restore from a backup file">&#8679; Restore</button>' +
    '  </div>' +
    '  <input type="file" id="sb-restore-input" accept="application/json" style="display:none" onchange="handleRestoreInput(this)">' +
    '  <div class="sb-footer">Balancing with Britt, LLC<br>All data stored locally in this browser</div>' +
    '</aside>';
}
function mountSidebar(active) {
  const mount = document.getElementById("sidebar-mount");
  if (mount) mount.outerHTML = sidebarHTML(active);
}
